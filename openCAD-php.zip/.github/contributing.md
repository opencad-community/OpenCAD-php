#### Bug Report

Please do not submit a bug report on GitHub if it contains a security vulnerability in OpenCAD or anything that may be considered sensitive. Please send an email to `security@opencad.io` as-if this was a GitHub Report.
  
 #### Pull Request

When submitting a pull request we ask that you sign your commits with a gpg key.
